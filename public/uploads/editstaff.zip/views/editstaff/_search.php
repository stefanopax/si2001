<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\SearchStaff */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="staff-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'cellphone') ?>

    <?= $form->field($model, 'phone') ?>

    <?= $form->field($model, 'mail') ?>

    <?= $form->field($model, 'room') ?>

    <?php $form->field($model, 'address') ?>

    <?php $form->field($model, 'image') ?>

    <?php $form->field($model, 'fax') ?>

    <?php $form->field($model, 'role') ?>

    <?php $form->field($model, 'description') ?>

    <?php echo $form->field($model, 'link') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
